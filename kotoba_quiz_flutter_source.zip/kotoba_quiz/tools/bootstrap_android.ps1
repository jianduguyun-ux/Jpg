$ErrorActionPreference = 'Stop'
Set-Location (Split-Path -Parent $PSScriptRoot)
$backup = Join-Path $env:TEMP 'kotoba-quiz-AndroidManifest.xml'
Copy-Item 'android/app/src/main/AndroidManifest.xml' $backup -Force
Remove-Item 'android' -Recurse -Force
flutter create --platforms=android --org com.kotobaquiz --project-name kotoba_quiz .
Copy-Item $backup 'android/app/src/main/AndroidManifest.xml' -Force
Remove-Item $backup -Force
Write-Host 'Android project generated. Run: flutter pub get; flutter build apk --release'

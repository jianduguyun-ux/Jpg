#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
MANIFEST_BACKUP="$(mktemp)"
cp android/app/src/main/AndroidManifest.xml "$MANIFEST_BACKUP"
rm -rf android
flutter create --platforms=android --org com.kotobaquiz --project-name kotoba_quiz .
cp "$MANIFEST_BACKUP" android/app/src/main/AndroidManifest.xml
rm -f "$MANIFEST_BACKUP"
echo "Android Gradle project generated. Run: flutter pub get && flutter build apk --release"

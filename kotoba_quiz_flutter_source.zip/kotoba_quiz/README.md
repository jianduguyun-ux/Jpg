# Kotoba Quiz — Flutter Android Offline

Aplikasi kuis kosakata Bahasa Jepang dengan 1.000 entri lokal, dua mode (Kanji dan Kana), konfigurasi timer/jumlah soal, randomisasi, rekap jawaban, dan grafik perkembangan lokal.

## Fitur
- 100% offline saat aplikasi berjalan: JSON disertakan di `assets/vocab.json`; tidak ada API/server.
- Mode Kanji atau Hiragana/Katakana, pertanyaan dua arah (Jepang → arti / arti → tulisan Jepang).
- Durasi 1, 2, 3, 5, 10 menit; timer otomatis menyelesaikan sesi.
- 5, 10, 15, 20 soal; tema dicampur dari seluruh kosakata.
- Soal dan opsi diacak; tombol ulangi membuat sesi acak baru.
- Skor, benar/salah, waktu, dan review jawaban.
- Riwayat dan grafik skor disimpan lokal memakai SharedPreferences.

## Persyaratan build
- Flutter stable (Dart sesuai `pubspec.yaml`), Android SDK, Android Studio/command-line tools.
- Internet hanya diperlukan satu kali untuk mengunduh Flutter packages dan Android Gradle dependencies ketika pertama kali build. APK hasil build dapat dipasang dan dipakai sepenuhnya offline.

## Siapkan proyek Android dan jalankan
ZIP berisi kode aplikasi dan manifest Android offline. Folder Gradle/Wrapper Android dibuat oleh Flutter sesuai versi SDK yang terpasang. Dari folder proyek jalankan sekali:

Linux/macOS:
```bash
bash tools/bootstrap_android.sh
```
Windows PowerShell:
```powershell
.\tools\bootstrap_android.ps1
```

Kemudian jalankan:
```bash
flutter doctor
flutter pub get
flutter run
```

## Build APK untuk Android
```bash
flutter pub get
flutter build apk --release
```
APK universal berada di:
`build/app/outputs/flutter-apk/app-release.apk`

Pindahkan APK ke HP Android, izinkan instalasi dari sumber yang dipilih bila diminta, lalu instal. Setelah terpasang, matikan Wi-Fi/data seluler untuk menguji mode offline.

## Build APK per arsitektur (opsional)
```bash
flutter build apk --release --split-per-abi
```
Hasil APK terpisah tersedia di folder `build/app/outputs/flutter-apk/`.

## Catatan database
File `assets/vocab.json` memuat tepat 1.000 entri dengan kolom `kanji`, `kana`, `romaji`, `meaning`, dan `theme`. Sebagian besar entri diekstrak dari PDF kosakata yang diberikan. Sebelas baris yang gagal diekstrak dengan rapi dari tata letak PDF dilengkapi sebagai entri tambahan bertema relevan; silakan tinjau dan koreksi bila ingin kesesuaian 100% dengan dokumen cetak. Ada juga beberapa baris PDF yang membungkus teks antarkolom; disarankan proofread JSON sebelum rilis publik.

## Struktur
```
lib/main.dart             # UI, quiz engine, timer, scoring, history, chart
assets/vocab.json         # 1.000 kosakata offline
pubspec.yaml              # dependencies + asset registration
android/app/src/main/AndroidManifest.xml
```
